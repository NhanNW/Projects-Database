﻿create database LibrarySystem
use LibrarySystem

create table Users(
	UserID nvarchar(10) primary key,
	UserPassword nvarchar(255) not null,
	UserEmail nvarchar(100) unique not null,
	UserPhone nvarchar(20),
	UserRole nvarchar(20) check (UserRole in ('Student', 'Teacher' , 'Librarian' )),
	UserCreateDate datetime	default getdate(),
	UserStatus bit default 1
);


create table Categories (
    category_id    nvarchar(6) primary key,
    category_name  NVARCHAR(100) NOT NULL UNIQUE
);

create table Books(
	BookID nvarchar(6) primary key,
	Title nvarchar(200) not null,
	Author nvarchar(200) ,
	Publisher nvarchar(200) ,
	BookImage nvarchar(255),
	YearPublished int check (YearPublished >= 2000 AND YearPublished <= YEAR(GETDATE())),
	CategoryID nvarchar(6) not null foreign key references Categories(category_id),
	TotalCopies int check (TotalCopies >=0),
	AvailableCopies int check (AvailableCopies >=0),
	Description nvarchar(500),
	Status bit default 1
);
alter table Books
add constraint chk_AvailableCopies_TotalCopies CHECK (AvailableCopies <= TotalCopies);

create table Borrowing (
    BorrowID nvarchar(6) primary key,
    UserID nvarchar(10) NOT NULL FOREIGN KEY REFERENCES Users(UserID),
    IsApproved BIT NOT NULL DEFAULT 0,              
    ApprovedBy nvarchar(10) NULL FOREIGN KEY REFERENCES Users(UserID), 
    ApprovedDate DATETIME NULL
);



create table BorrowDetails (
    BorrowID nvarchar(6) foreign key references Borrowing(BorrowID),
    BookID nvarchar(6) foreign key references Books(BookID),
    Quantity int check (Quantity > 0),
	BorrowDate datetime null,
    DueDate datetime NOT NULL,
    ReturnDate datetime NULL , 
	Status nvarchar(30),
    primary key (BorrowID, BookID)
);


alter table BorrowDetails 
add IsReturnRequested bit default 0;

create table Fines (
    FineID nvarchar(6) PRIMARY KEY,
    BorrowID nvarchar(6) NOT NULL FOREIGN KEY REFERENCES Borrowing(BorrowID),
    Amount money CHECK (Amount >= 0),
    FineDate datetime DEFAULT GETDATE(),
	Reason nvarchar(100),
    IsPaid bit DEFAULT 0,
    CreatedBy nvarchar(10) NOT NULL FOREIGN KEY REFERENCES Users(UserID) 
);

create table Reservations (
    ReservationID nvarchar(6) PRIMARY KEY,
    UserID nvarchar(10) NOT NULL FOREIGN KEY REFERENCES Users(UserID),
    BookID nvarchar(6) NOT NULL FOREIGN KEY REFERENCES Books(BookID),
    ReservationDate datetime DEFAULT GETDATE(),
	Quantity int not null default 1 check(Quantity between 1 and 5),
	ApprovedBy nvarchar(10) null foreign key references Users(UserID),
    Status nvarchar(20) CHECK (Status IN ('Pending', 'Cancelled', 'Completed')) DEFAULT 'Pending' ,
	ApprovedDate datetime null,
);

go
create trigger trg_OnlyLibrarianCanApprove
ON Borrowing
for UPDATE
as
begin
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN deleted d ON i.BorrowID = d.BorrowID
        JOIN Users u ON i.ApprovedBy = u.UserID
        WHERE i.IsApproved = 1 
          AND (d.IsApproved = 0 OR d.IsApproved IS NULL)  
          AND (u.UserRole != 'Librarian' OR i.ApprovedBy IS NULL)
    )
    BEGIN
        RAISERROR('Chỉ thủ thư mới có quyền duyệt mượn sách.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
END;
GO

go
GO
create trigger trg_BorrowDetails_InsertCheck
on BorrowDetails
instead of insert
as
begin
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Books b ON i.BookID = b.BookID
        WHERE i.Quantity > b.AvailableCopies
    )
    BEGIN
        RAISERROR(N'Số lượng sách mượn vượt quá số sách hiện có.', 16, 1);
        RETURN;
    END

    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Borrowing br ON i.BorrowID = br.BorrowID
        WHERE br.IsApproved = 0 OR br.IsApproved IS NULL
    )
    BEGIN
        RAISERROR(N'Chỉ được phép mượn sách khi yêu cầu đã được thủ thư duyệt.', 16, 1);
        RETURN;
    END

    UPDATE Books
    SET AvailableCopies = b.AvailableCopies - i.Quantity
    FROM Books b
    JOIN INSERTED i ON b.BookID = i.BookID;

    INSERT INTO BorrowDetails (BorrowID, BookID, Quantity, BorrowDate, DueDate, ReturnDate)
    SELECT BorrowID, BookID, Quantity, BorrowDate, DueDate, ReturnDate
    FROM INSERTED;
END;
GO



go
create trigger trg_EnsureLibrarianApproval
on Reservations
for insert,update
as
begin
    SET NOCOUNT ON;
	if exists (
        SELECT 1
        FROM inserted i
        JOIN Users u ON i.ApprovedBy = u.UserID
        WHERE i.ApprovedBy IS NOT NULL AND u.UserRole != 'Librarian'
    )
    BEGIN
        RAISERROR('Chỉ thủ thư là người được duyệt.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;



go
create trigger trg_OnlyLibrarianCreateFines
on Fines
for insert, update
as
begin
    
    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Users u ON i.CreatedBy = u.UserID
        WHERE u.UserRole != 'Librarian'
    )
    BEGIN
        RAISERROR('Chỉ thủ thư có thể tạo phiếu phạt', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
go

go
create trigger trg_DueDateCheck
on BorrowDetails
for insert, update
as
begin
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted
        WHERE DueDate < BorrowDate
    )
    BEGIN
        RAISERROR(N'DueDate phải lớn hơn hoặc bằng BorrowDate.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END
go



create trigger trg_TuDongTangSoLuongBanCopy
on BorrowDetails
for UPDATE
as
begin
    SET NOCOUNT ON;

    IF UPDATE(ReturnDate)
    BEGIN
        UPDATE b
        SET AvailableCopies = b.AvailableCopies + bd.Quantity
        FROM Books b
        JOIN BorrowDetails bd ON b.BookID = bd.BookID
        JOIN inserted i ON i.BorrowID = bd.BorrowID
        JOIN deleted d ON d.BorrowID = i.BorrowID
        WHERE d.ReturnDate IS NULL AND i.ReturnDate IS NOT NULL
    END
END;

go
create trigger trg_BorrowingStatus
on BorrowDetails
for insert, update
as
begin
    SET NOCOUNT ON;

    UPDATE bd
    SET Status = CASE 
                    WHEN bd.ReturnDate IS NULL THEN 'Borrowed'
                    WHEN bd.ReturnDate > bd.DueDate THEN 'Overdue'
                    ELSE 'Returned'
                 END
    FROM BorrowDetails bd
    INNER JOIN inserted i ON bd.BorrowID = i.BorrowID AND bd.BookID = i.BookID;
END;
GO

GO

go

create trigger trg_CheckReturnDate
on BorrowDetails
for insert, update
as
begin
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 FROM inserted
        WHERE ReturnDate IS NOT NULL AND ReturnDate > GETDATE()
    )
    BEGIN
        RAISERROR('ReturnDate không được lớn hơn ngày hiện tại.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

go

create trigger trg_LimitBooksPerBorrow
on BorrowDetails
for insert, update
as
begin
    IF EXISTS (
        SELECT 1
        FROM BorrowDetails
        WHERE BorrowID IN (SELECT BorrowID FROM INSERTED)
        GROUP BY BorrowID
        HAVING SUM(Quantity) > 5
    )
    BEGIN
        ROLLBACK;
        RAISERROR(N'Each time can only borrow 5 books. ', 16, 1);
    END
END;
go

go
CREATE TRIGGER trg_ChiDatTruocKhiHetSach
ON Reservations
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Books b ON i.BookID = b.BookID
        WHERE b.AvailableCopies > 0
    )
    BEGIN
        RAISERROR(N'Chỉ được đặt trước sách khi tất cả các bản sao đã được mượn (AvailableCopies = 0)', 16, 1);
        RETURN;
    END

    insert into Reservations (ReservationID, UserID, BookID, ReservationDate,Quantity, Status)
    SELECT ReservationID, UserID, BookID, ReservationDate,Quantity, Status
    FROM inserted;
END;
go


insert into Users values 
('2280602150', '2280602150', 'aothanhnhan4@example.com', '0123456789', 'Student', GETDATE(), 1),
('2280600534', '2280600534', 'tranngocanhduong0907@gmail.com', '987654321', 'Student', GETDATE(), 1),
('2280600194', '2280600194', 'Vangpq@gmail.com', '0111222333', 'Student', GETDATE(), 1),
('Lib01', 'librarian123', 'thuthu@gmail.com', '02233445566', 'Librarian', '8-1-2024', 1),
('Teacher01', '12345', 'giangvien1@gmail.com', '0908070605', 'Teacher', '2-22-2024',1)
;


insert into Categories values 
('CAT001', 'Computer Science'),
('CAT002', 'Literature'),
('CAT003', 'Mathematics');

insert into Books values 
('B00001', 'Introduction to Algorithms', 'Thomas H. Cormen', 'MIT Press', 'algorithms.jpg', 2020, 'CAT001', 10, 10, 'Classic CS book', 1),
('B00002', 'Romeo and Juliet', 'William Shakespeare', 'Oxford Press', 'rj.jpg', 2018, 'CAT002', 5, 5, 'Famous tragedy', 1),
('B00003', 'Linear Algebra Done Right', 'Sheldon Axler', 'Springer', 'linear.jpg', 2019, 'CAT003', 3, 0, 'Mathematics textbook', 1);

insert into Borrowing (BorrowID, UserID, IsApproved, ApprovedBy, ApprovedDate)
values 
('BR0001', '2280600534', 1, 'Lib01', GETDATE()),    -- đã duyệt bởi thủ thư
('BR0002', '2280600194', 0, NULL, NULL);            -- chưa duyệt

insert into BorrowDetails (BorrowID, BookID, Quantity, BorrowDate, DueDate, ReturnDate)
values
-- Với BorrowID đã duyệt (BR0001), có BorrowDate, DueDate 
('BR0001', 'B00001', 2, GETDATE(), DATEADD(DAY, 7, GETDATE()), NULL),
('BR0001', 'B00002', 1, GETDATE(), DATEADD(DAY, 7, GETDATE()), NULL);

insert into Fines (FineID, BorrowID, Amount, Reason, IsPaid, CreatedBy)
values 
('F00001', 'BR0001', 10000, 'Trả trễ hạn', 1, 'Lib01');


insert into Reservations (ReservationID, UserID, BookID, ReservationDate, Quantity, ApprovedBy, Status, ApprovedDate)
values
('RS0001', '2280602150', 'B00003', GETDATE(), 1, NULL, 'Pending', NULL);


CREATE TABLE Notifications (
    NotificationID NVARCHAR(6) PRIMARY KEY,
    UserID NVARCHAR(10) NOT NULL FOREIGN KEY REFERENCES Users(UserID),
    Title NVARCHAR(255),
    Message NVARCHAR(MAX),
    CreatedBy NVARCHAR(10) NOT NULL FOREIGN KEY REFERENCES Users(UserID), 
    CreatedDate DATETIME DEFAULT GETDATE(),
    IsRead BIT DEFAULT 0  
);

GO
CREATE TRIGGER trg_OnlyLibrarianCanCreateNotification
ON Notifications
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Users u ON i.CreatedBy = u.UserID
        WHERE u.UserRole != 'Librarian'
    )
    BEGIN
        RAISERROR(N'Only librarian can create an notification', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

INSERT INTO Notifications (NotificationID, UserID, Title, Message, CreatedBy)
VALUES 
(
    'NT0001', '2280600534', N'Nhắc trả sách đúng hạn', N'Bạn vui lòng trả sách "Introduction to Algorithms" trước ngày hết hạn để tránh bị phạt.','Lib01'                  
);



create table BorrowRequests (
RequestID nvarchar(6),
BorrowID nvarchar(6) not null foreign key references Borrowing(BorrowID),
BookID nvarchar(6) not null foreign key references Books(BookID),
Quantity int not null check (Quantity>0)
);

insert into BorrowRequests (RequestID, BorrowID, BookID, Quantity)
values ('RQ0001', 'BR0002', 'B00001', 1),
		('RQ0002', 'BR0002', 'B00002', 1);


select * from Users
select * from Books
select * from Borrowing
select * from BorrowDetails
select * from BorrowRequests
select * from Categories
select * from Fines
select * from Reservations
select * from Notifications
