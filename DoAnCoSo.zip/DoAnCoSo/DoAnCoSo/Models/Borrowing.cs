﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class Borrowing
    {
        public string BorrowID { get; set; }
        public string UserID { get; set; }
        public string UserRole { get; set; }

        public bool IsApproved { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public DateTime? RequestDate { get; set; }

    }
}