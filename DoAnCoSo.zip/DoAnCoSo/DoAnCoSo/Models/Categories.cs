﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class Categories
    {
        public string category_id { get; set; }
        public string category_name { get; set; }
    }
}