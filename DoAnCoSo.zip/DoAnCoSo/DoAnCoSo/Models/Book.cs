﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class Book
    {

        [Required(ErrorMessage = "Mã sách bắt buộc nhập")]
        public string BookID { get; set; }

        [Required(ErrorMessage = "Tên sách bắt buộc nhập")]
        public string Title { get; set; }

        public string Author { get; set; }
        public string Publisher { get; set; }
        public string BookImage { get; set; }

        [Required(ErrorMessage = "Năm xuất bản bắt buộc nhập")]
        public int? YearPublished { get; set; }

        [Required(ErrorMessage = "Thể loại bắt buộc chọn")]
        public string CategoryID { get; set; }

        [Required(ErrorMessage = "Tổng số lượng bắt buộc nhập")]
        public int? TotalCopies { get; set; }

        public int? AvailableCopies { get; set; }
        [StringLength(500, ErrorMessage = "Mô tả không được vượt quá 500 ký tự.")]
        public string Description { get; set; }
        public bool Status { get; set; } = true;
        public DateTime? CreatedDate { get; set; }

    }
}
