﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class Notification
    {
        public string NotificationID { get; set; }      // NT0001, NT0002, ...
        public string UserID { get; set; }              // Người nhận thông báo
        public string Title { get; set; }               // Tiêu đề
        public string Message { get; set; }             // Nội dung
        public string CreatedBy { get; set; }           // Người tạo (Librarian)
        public DateTime CreatedDate { get; set; }       // Ngày tạo
        public bool IsRead { get; set; }
    }
}