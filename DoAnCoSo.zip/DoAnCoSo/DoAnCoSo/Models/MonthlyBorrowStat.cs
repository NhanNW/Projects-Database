﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class MonthlyBorrowStat
    {
        public int Month { get; set; }
        public int Total { get; set; }
    }
}