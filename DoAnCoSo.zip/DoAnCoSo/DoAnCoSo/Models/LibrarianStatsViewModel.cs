﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class LibrarianStatsViewModel
    {
        public int TotalBooks { get; set; }
        public int TotalUsers { get; set; }
        public int CurrentlyBorrowed { get; set; }
        public int OverdueBooks { get; set; }
        public int ApprovedBorrowings { get; set; }
        public int DiscontinuedBooks { get; set; }
    }
}