﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class Reservation
    {
        public string ReservationID { get; set; }
        public string UserID { get; set; }
        public string BookTitle { get; set; }
        public DateTime ReservationDate { get; set; }
        public int Quantity { get; set; }
        public string ApprovedBy { get; set; }
        public string Status { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public Book Book { get; set; } // để hiển thị tên sách trong View

    }
}