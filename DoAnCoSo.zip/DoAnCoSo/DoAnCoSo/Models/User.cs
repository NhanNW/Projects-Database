﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class User
    {
        [Key]
        [StringLength(10)]
        public string UserID { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string UserEmail { get; set; }

        [Phone]
        [StringLength(10)]
        public string UserPhone { get; set; }

        [Required]
        [StringLength(20)]
        [RegularExpression("Student|Teacher|Librarian", ErrorMessage = "UserRole must be Student, Teacher, or Librarian.")]
        public string UserRole { get; set; }

        public DateTime UserCreateDate { get; set; } = DateTime.Now;

        public bool UserStatus { get; set; } = true;
    }
}