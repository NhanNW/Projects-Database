﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class ApprovedBorrowingViewModel
    {
        public string BorrowID { get; set; }
        public string UserID { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public List<BorrowedBookInfo> BorrowedBooks { get; set; }
    }
}