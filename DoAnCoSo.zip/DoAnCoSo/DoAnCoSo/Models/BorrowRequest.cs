﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoAnCoSo.Models
{
    public class BorrowRequest
    {
        public string RequestID { get; set; }      // Mã yêu cầu chi tiết
        public string BorrowID { get; set; }       // Mã mượn sách chung
        public string BookID { get; set; }         // Mã sách
        public int Quantity { get; set; }          // Số lượng mượn
    }
}