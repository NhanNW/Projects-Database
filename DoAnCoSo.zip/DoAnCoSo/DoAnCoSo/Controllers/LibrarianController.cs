﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class LibrarianController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";
        // GET: Librarian
        public ActionResult LibrarianDashboard()
        {
            var books = new List<Book>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"SELECT BookID, Title, Author, Publisher, BookImage, YearPublished, 
                                      CategoryID, TotalCopies, AvailableCopies, Description, Status 
                               FROM Books";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        books.Add(new Book
                        {
                            BookID = reader["BookID"].ToString(),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            Publisher = reader["Publisher"].ToString(),
                            BookImage = reader["BookImage"] != DBNull.Value ? reader["BookImage"].ToString() : null,
                            YearPublished = reader["YearPublished"] != DBNull.Value ? Convert.ToInt32(reader["YearPublished"]) : 0,
                            CategoryID = reader["CategoryID"].ToString(),
                            TotalCopies = reader["TotalCopies"] != DBNull.Value ? Convert.ToInt32(reader["TotalCopies"]) : 0,
                            AvailableCopies = reader["AvailableCopies"] != DBNull.Value ? Convert.ToInt32(reader["AvailableCopies"]) : 0,
                            Description = reader["Description"] != DBNull.Value ? reader["Description"].ToString() : "",
                            Status = reader["Status"] != DBNull.Value && Convert.ToBoolean(reader["Status"])
                        });
                    }

                }
            }
            return View(books);
        }

        public ActionResult ManageUsers()
        {
            ViewBag.HideSearch = true;

            var users = new List<User>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = "SELECT UserID, UserPassword, UserEmail, UserPhone, UserRole, UserCreateDate, UserStatus FROM Users";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(new User
                        {
                            UserID = reader["UserID"].ToString(),
                            Password = reader["UserPassword"].ToString(),
                            UserEmail = reader["UserEmail"].ToString(),
                            UserPhone = reader["UserPhone"].ToString(),
                            UserRole = reader["UserRole"].ToString(),
                            UserCreateDate = Convert.ToDateTime(reader["UserCreateDate"]),
                            UserStatus = Convert.ToBoolean(reader["UserStatus"])
                        });
                    }
                }
            }
            return View(users);
        }

        public ActionResult CreateUser()
        {
            ViewBag.HideSearch = true;
            return View();
        }

        // POST: Librarian/CreateUser
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateUser(User user)
        {
            ViewBag.HideSearch = true;

            if (user.UserCreateDate > DateTime.Now.Date)
            {
                ModelState.AddModelError("UserCreateDate", "Created Date cannot be in the future.");
            }

            if (!ModelState.IsValid)
                return View(user);

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"INSERT INTO Users (UserID, UserPassword, UserEmail, UserPhone, UserRole, UserCreateDate, UserStatus) 
               VALUES (@UserID, @UserPassword, @UserEmail, @UserPhone, @UserRole, @UserCreateDate, @UserStatus)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", user.UserID);
                    cmd.Parameters.AddWithValue("@UserPassword", user.Password);
                    cmd.Parameters.AddWithValue("@UserEmail", user.UserEmail);
                    cmd.Parameters.AddWithValue("@UserPhone", user.UserPhone);
                    cmd.Parameters.AddWithValue("@UserRole", user.UserRole);
                    cmd.Parameters.AddWithValue("@UserCreateDate", user.UserCreateDate);
                    cmd.Parameters.AddWithValue("@UserStatus", user.UserStatus);
                    cmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("ManageUsers");
        }

        // GET: Librarian/EditUser?id=someid
        public ActionResult EditUser(string id)
        {
            ViewBag.HideSearch = true;

            if (string.IsNullOrWhiteSpace(id))
                return RedirectToAction("ManageUsers");

            User user = null;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = "SELECT UserID, UserPassword, UserEmail, UserPhone, UserRole, UserCreateDate, UserStatus FROM Users WHERE UserID = @UserID";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", id);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            user = new User
                            {
                                UserID = reader["UserID"].ToString(),
                                Password = reader["UserPassword"].ToString(),
                                UserEmail = reader["UserEmail"].ToString(),
                                UserPhone = reader["UserPhone"].ToString(),
                                UserRole = reader["UserRole"].ToString(),
                                UserCreateDate = Convert.ToDateTime(reader["UserCreateDate"]),
                                UserStatus = Convert.ToBoolean(reader["UserStatus"])
                            };
                        }
                    }
                }
            }

            if (user == null)
                return HttpNotFound();

            return View(user);
        }

        // POST: Librarian/EditUser
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditUser(User model)
        {
            ViewBag.HideSearch = true;
            ModelState["Password"].Errors.Clear();
            if (!ModelState.IsValid)
                return View(model);

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"UPDATE Users SET UserEmail=@UserEmail, UserPhone=@UserPhone, UserRole=@UserRole, 
               UserCreateDate=@UserCreateDate, UserStatus=@UserStatus WHERE UserID=@UserID";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", model.UserEmail);
                    cmd.Parameters.AddWithValue("@UserPhone", model.UserPhone);
                    cmd.Parameters.AddWithValue("@UserRole", model.UserRole);
                    cmd.Parameters.AddWithValue("@UserCreateDate", model.UserCreateDate);
                    cmd.Parameters.AddWithValue("@UserStatus", model.UserStatus);
                    cmd.Parameters.AddWithValue("@UserID", model.UserID);

                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToAction("ManageUsers");
        }

        public ActionResult DeactivateUser(string id)
        {
            if (string.IsNullOrEmpty(id)) return RedirectToAction("UserList");

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "UPDATE Users SET UserStatus = 0 WHERE UserID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
            }

            TempData["SuccessMessage"] = "✅ User deactivated successfully.";
            return RedirectToAction("ManageUsers");
        }

        // ✅ Kích hoạt lại user (nếu cần)
        public ActionResult ActivateUser(string id)
        {
            if (string.IsNullOrEmpty(id)) return RedirectToAction("UserList");

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "UPDATE Users SET UserStatus = 1 WHERE UserID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
            }

            TempData["SuccessMessage"] = "✅ User activated successfully.";
            return RedirectToAction("ManageUsers");
        }




        // GET: EnterBook
        public ActionResult EnterBook()
        {
            ViewBag.HideSearch = true;
            ViewBag.Categories = GetCategoryList();

            var book = new Book
            {
                CreatedDate = DateTime.Now,
                Status = true
            };

            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EnterBook(Book model, HttpPostedFileBase BookImageFile)
        {

            ViewBag.HideSearch = true;
            ViewBag.Categories = GetCategoryList();

            // Kiểm tra các trường số nguyên nullable
            if (!model.TotalCopies.HasValue || model.TotalCopies < 0)
            {
                ModelState.AddModelError("TotalCopies", "The total quantity must be greater than or equal to 0.");
            }

            if (!model.YearPublished.HasValue || model.YearPublished < 2000 || model.YearPublished > DateTime.Now.Year)
            {
                ModelState.AddModelError("YearPublished", "The publication year must be from 2000 to the present.");
            }

            // Set AvailableCopies = TotalCopies nếu không hợp lệ hoặc null
            if (!model.AvailableCopies.HasValue || model.AvailableCopies <= 0)
            {
                model.AvailableCopies = model.TotalCopies;
            }

            if (model.AvailableCopies > model.TotalCopies)
            {
                ModelState.AddModelError("AvailableCopies", "The remaining quantity must not be greater than the total quantity.");
            }

            // Kiểm tra ModelState trước khi tiếp tục
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                // Check duplicate BookID
                using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Books WHERE BookID = @BookID", conn))
                {
                    checkCmd.Parameters.AddWithValue("@BookID", model.BookID);
                    if ((int)checkCmd.ExecuteScalar() > 0)
                    {
                        ModelState.AddModelError("BookID", "The book ID already exists.");
                        return View(model);
                    }
                }

                // Check if CategoryID exists
                using (SqlCommand catCmd = new SqlCommand("SELECT COUNT(*) FROM Categories WHERE category_id = @CategoryID", conn))
                {
                    catCmd.Parameters.AddWithValue("@CategoryID", model.CategoryID);
                    if ((int)catCmd.ExecuteScalar() == 0)
                    {
                        ModelState.AddModelError("CategoryID", "The category does not exist.");
                        return View(model);
                    }
                }
            }

            // Save image if provided
            string fileName = null;
            if (BookImageFile != null && BookImageFile.ContentLength > 0)
            {
                fileName = Path.GetFileName(BookImageFile.FileName);
                string filePath = Path.Combine(Server.MapPath("~/BookImages"), fileName);
                BookImageFile.SaveAs(filePath);
            }

            // Insert book into DB
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string sql = @"
           INSERT INTO Books 
           (BookID, Title, Author, Publisher, YearPublished, CategoryID, TotalCopies, AvailableCopies, BookImage, Description, Status)
           VALUES 
           (@BookID, @Title, @Author, @Publisher, @YearPublished, @CategoryID, @TotalCopies, @AvailableCopies, @BookImage, @Description, @Status)";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@BookID", model.BookID);
                    cmd.Parameters.AddWithValue("@Title", model.Title ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Author", model.Author ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Publisher", model.Publisher ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@YearPublished", model.YearPublished);
                    cmd.Parameters.AddWithValue("@CategoryID", model.CategoryID);
                    cmd.Parameters.AddWithValue("@TotalCopies", model.TotalCopies);
                    cmd.Parameters.AddWithValue("@AvailableCopies", model.AvailableCopies);
                    cmd.Parameters.AddWithValue("@BookImage", fileName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Description", model.Description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Status", model.Status);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            TempData["Success"] = "📚 Add new book successfully!";
            return RedirectToAction("EnterBook");
        }

        public ActionResult EditBook(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return RedirectToAction("LibrarianDashboard");

            Book book = null;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"SELECT BookID, Title, Author, Publisher, BookImage, YearPublished, 
                              CategoryID, TotalCopies, AvailableCopies, Description, Status 
                       FROM Books WHERE BookID = @BookID";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@BookID", id);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            book = new Book
                            {
                                BookID = reader["BookID"]?.ToString(),
                                Title = reader["Title"]?.ToString(),
                                Author = reader["Author"]?.ToString(),
                                Publisher = reader["Publisher"]?.ToString(),
                                BookImage = reader["BookImage"]?.ToString(),
                                YearPublished = reader["YearPublished"] == DBNull.Value ? 0 : Convert.ToInt32(reader["YearPublished"]),
                                CategoryID = reader["CategoryID"]?.ToString(),
                                TotalCopies = reader["TotalCopies"] == DBNull.Value ? 0 : Convert.ToInt32(reader["TotalCopies"]),
                                AvailableCopies = reader["AvailableCopies"] == DBNull.Value ? 0 : Convert.ToInt32(reader["AvailableCopies"]),
                                Description = reader["Description"]?.ToString(),
                                Status = reader["Status"] == DBNull.Value ? false : Convert.ToBoolean(reader["Status"])
                            };
                        }
                    }
                }
            }

            if (book == null)
                return HttpNotFound();

            ViewBag.Categories = GetCategoryList(); // để chọn thể loại trong form
            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditBook(Book model, HttpPostedFileBase BookImageFile)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = GetCategoryList();
                return View(model);
            }
            // Nếu có ảnh mới thì lưu lại, nếu không giữ nguyên
            string fileName = model.BookImage;
            if (BookImageFile != null && BookImageFile.ContentLength > 0)
            {
                fileName = Path.GetFileName(BookImageFile.FileName);
                string path = Path.Combine(Server.MapPath("~/BookImages"), fileName);
                BookImageFile.SaveAs(path);
            }

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string sql = @"UPDATE Books 
                       SET Title = @Title, Author = @Author, Publisher = @Publisher,
                           YearPublished = @YearPublished, CategoryID = @CategoryID,
                           TotalCopies = @TotalCopies, AvailableCopies = @AvailableCopies,
                           BookImage = @BookImage, Description = @Description, Status = @Status
                       WHERE BookID = @BookID";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Title", model.Title);
                    cmd.Parameters.AddWithValue("@Author", model.Author);
                    cmd.Parameters.AddWithValue("@Publisher", model.Publisher);
                    cmd.Parameters.AddWithValue("@YearPublished", model.YearPublished);
                    cmd.Parameters.AddWithValue("@CategoryID", model.CategoryID);
                    cmd.Parameters.AddWithValue("@TotalCopies", model.TotalCopies);
                    cmd.Parameters.AddWithValue("@AvailableCopies", model.AvailableCopies);
                    cmd.Parameters.AddWithValue("@BookImage", fileName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Description", model.Description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Status", model.Status);
                    cmd.Parameters.AddWithValue("@BookID", model.BookID);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }

            TempData["Success"] = "✔️ Cập nhật sách thành công!";
            return RedirectToAction("LibrarianDashboard");
        }

        private List<SelectListItem> GetCategoryList()
        {
            var categories = new List<SelectListItem>();
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();
                string sql = "SELECT category_id, category_name FROM Categories";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new SelectListItem
                        {
                            Value = reader["category_id"].ToString(),
                            Text = reader["category_name"].ToString()
                        });
                    }
                }
            }
            return categories;
        }
        //public ActionResult ApprovedUsers()
        //{
        //    List<ApprovedBorrowingViewModel> approvedList = new List<ApprovedBorrowingViewModel>();

        //    using (SqlConnection con = new SqlConnection(conStr))
        //    {
        //        string query = @"
        //    SELECT br.BorrowID, br.UserID, br.ApprovedBy, br.ApprovedDate,
        //           bd.BookID, b.Title, bd.BorrowDate, bd.DueDate, bd.Status
        //    FROM Borrowing br
        //    LEFT JOIN BorrowDetails bd ON br.BorrowID = bd.BorrowID
        //    LEFT JOIN Books b ON bd.BookID = b.BookID
        //    WHERE br.IsApproved = 1
        //    ORDER BY br.BorrowID, bd.BookID";

        //        using (SqlCommand cmd = new SqlCommand(query, con))
        //        {
        //            con.Open();
        //            SqlDataReader reader = cmd.ExecuteReader();

        //            Dictionary<string, ApprovedBorrowingViewModel> borrowMap = new Dictionary<string, ApprovedBorrowingViewModel>();

        //            while (reader.Read())
        //            {
        //                string borrowId = reader["BorrowID"].ToString();

        //                if (!borrowMap.ContainsKey(borrowId))
        //                {
        //                    borrowMap[borrowId] = new ApprovedBorrowingViewModel
        //                    {
        //                        BorrowID = borrowId,
        //                        UserID = reader["UserID"].ToString(),
        //                        ApprovedBy = reader["ApprovedBy"]?.ToString(),
        //                        ApprovedDate = reader["ApprovedDate"] as DateTime?,
        //                        BorrowedBooks = new List<BorrowedBookInfo>()
        //                    };
        //                }

        //                // Nếu có dữ liệu sách
        //                if (reader["BookID"] != DBNull.Value)
        //                {
        //                    borrowMap[borrowId].BorrowedBooks.Add(new BorrowedBookInfo
        //                    {
        //                        BookID = reader["BookID"].ToString(),
        //                        Title = reader["Title"].ToString(),
        //                        BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
        //                        DueDate = Convert.ToDateTime(reader["DueDate"]),
        //                        Status = reader["Status"].ToString()
        //                    });
        //                }
        //            }

        //            reader.Close();

        //            approvedList = borrowMap.Values.ToList();
        //        }
        //    }

        //    return View(approvedList);
        //}

        [HttpGet]
        public ActionResult CreateBorrowDetail(string borrowID, string userID)
        {
            DateTime approvedDate = DateTime.Now;

            if (string.IsNullOrEmpty(borrowID) || string.IsNullOrEmpty(userID))
            {
                TempData["Error"] = "Missing BorrowID or UserID.";
                return RedirectToAction("ApprovedUsers");
            }

            ViewBag.BorrowID = borrowID;
            ViewBag.UserID = userID;

            var approvedBooks = new List<Tuple<string, string>>();
            var requestedBooks = new List<Tuple<string, string>>();
            var availableBooks = new List<Tuple<string, string>>();

            using (SqlConnection con = new SqlConnection(conStr))
            {   
                con.Open();

                // Get already approved books
                string approvedQuery = @"SELECT b.BookID, b.Title
                                  FROM BorrowDetails bd
                                  JOIN Books b ON bd.BookID = b.BookID
                                  WHERE bd.BorrowID = @BorrowID";

                using (SqlCommand cmd = new SqlCommand(approvedQuery, con))
                {
                    cmd.Parameters.AddWithValue("@BorrowID", borrowID);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            approvedBooks.Add(Tuple.Create(reader["BookID"].ToString(), reader["Title"].ToString()));
                        }
                    }
                }

                if (approvedBooks.Count == 0)
                {
                    string requestedQuery = @"SELECT br.BookID, b.Title
                                       FROM BorrowRequests br
                                       JOIN Books b ON br.BookID = b.BookID
                                       WHERE br.BorrowID = @BorrowID";

                    using (SqlCommand cmd = new SqlCommand(requestedQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@BorrowID", borrowID);
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                requestedBooks.Add(Tuple.Create(rdr["BookID"].ToString(), rdr["Title"].ToString()));
                            }
                        }
                    }
                }

                if (approvedBooks.Count == 0 && requestedBooks.Count == 0)
                {
                    string availableQuery = "SELECT BookID, Title FROM Books WHERE AvailableCopies > 0";
                    using (SqlCommand cmd = new SqlCommand(availableQuery, con))
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            availableBooks.Add(Tuple.Create(rdr["BookID"].ToString(), rdr["Title"].ToString()));
                        }
                    }
                }
                string dateQuery = "SELECT ApprovedDate FROM Borrowing WHERE BorrowID = @BorrowID";
                using (SqlCommand cmd = new SqlCommand(dateQuery, con))
                {
                    cmd.Parameters.AddWithValue("@BorrowID", borrowID);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        approvedDate = Convert.ToDateTime(result);
                    }
                }
            }

            ViewBag.ApprovedBooks = approvedBooks;
            ViewBag.RequestedBooks = requestedBooks;
            ViewBag.AllAvailableBooks = availableBooks;
            ViewBag.ApprovedDate = approvedDate;

            return View();
        }



        [HttpPost]
        public ActionResult CreateBorrowDetail(string BorrowID, string UserID, DateTime BorrowDate, DateTime DueDate, string[] SelectedBookIDs)
        {
            if (BorrowDate.Date < DateTime.Today)
            {
                TempData["Error"] = "Borrow date cannot be in the past.";
                return RedirectToAction("CreateBorrowDetail", new { borrowID = BorrowID, userID = UserID });
            }

            if (DueDate <= BorrowDate)
            {
                TempData["Error"] = "Due date must be after borrow date.";
                return RedirectToAction("CreateBorrowDetail", new { borrowID = BorrowID, userID = UserID });
            }
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlTransaction transaction = con.BeginTransaction();

                try
                {
                    List<string> bookList = new List<string>();

                    if (SelectedBookIDs != null && SelectedBookIDs.Length > 0)
                    {
                        bookList.AddRange(SelectedBookIDs);
                    }
                    else
                    {
                        string query = @"SELECT BookID FROM BorrowRequests WHERE BorrowID = @BorrowID";
                        SqlCommand cmd = new SqlCommand(query, con, transaction);
                        cmd.Parameters.AddWithValue("@BorrowID", BorrowID);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookList.Add(reader["BookID"].ToString());
                            }
                        }
                    }

                    if (bookList.Count == 0)
                    {
                        TempData["Error"] = "No books selected or found.";
                        transaction.Rollback();
                        return RedirectToAction("ApprovedUsers");
                    }

                    foreach (var bookID in bookList)
                    {
                        string insertSql = @"INSERT INTO BorrowDetails (BorrowID, BookID, BorrowDate, DueDate, Status)
                                     VALUES (@BorrowID, @BookID, @BorrowDate, @DueDate, 'Borrowed')";

                        SqlCommand insertCmd = new SqlCommand(insertSql, con, transaction);
                        insertCmd.Parameters.AddWithValue("@BorrowID", BorrowID);
                        insertCmd.Parameters.AddWithValue("@BookID", bookID);
                        insertCmd.Parameters.AddWithValue("@BorrowDate", BorrowDate);
                        insertCmd.Parameters.AddWithValue("@DueDate", DueDate);
                        insertCmd.ExecuteNonQuery();

                        SqlCommand updateStock = new SqlCommand(
                            "UPDATE Books SET AvailableCopies = AvailableCopies - 1 WHERE BookID = @BookID AND AvailableCopies > 0",
                            con, transaction);
                        updateStock.Parameters.AddWithValue("@BookID", bookID);
                        updateStock.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    TempData["Success"] = "✅ Borrow detail created successfully.";
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    TempData["Error"] = "❌ Error: " + ex.Message;
                }
            }

            return RedirectToAction("ApprovedUsers");
        }



        public ActionResult OverdueBooks()
        {
            var overdueBooks = new List<OverdueBook>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"
            SELECT 
                bd.BorrowID,
                bd.BookID,
                b.Title,
                b.Author,
                bd.BorrowDate,
                bd.DueDate,
                u.UserID,
                u.UserEmail,
                u.UserPhone
            FROM BorrowDetails bd
            JOIN Books b ON bd.BookID = b.BookID
            JOIN Borrowing br ON bd.BorrowID = br.BorrowID
            JOIN Users u ON br.UserID = u.UserID
            WHERE bd.ReturnDate IS NULL AND bd.DueDate < GETDATE();";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            var book = new OverdueBook
                            {
                                BorrowID = rdr["BorrowID"].ToString(),
                                BookID = rdr["BookID"].ToString(),
                                Title = rdr["Title"].ToString(),
                                Author = rdr["Author"].ToString(),
                                BorrowDate = (DateTime)rdr["BorrowDate"],
                                DueDate = (DateTime)rdr["DueDate"],
                                UserID = rdr["UserID"].ToString(),
                                UserEmail = rdr["UserEmail"].ToString(),
                                UserPhone = rdr["UserPhone"].ToString()
                            };
                            overdueBooks.Add(book);
                        }
                    }
                }
            }
            return View(overdueBooks);
        }

        public ActionResult ViewBorrowToConfirm()
        {
            List<ReturnRequest> list = new List<ReturnRequest>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"
                    SELECT bd.BorrowID, bd.BookID, b.Title, b.Author,
                           bd.BorrowDate, bd.DueDate, u.UserID, u.UserEmail, u.UserPhone
                    FROM BorrowDetails bd
                    JOIN Borrowing br ON bd.BorrowID = br.BorrowID
                    JOIN Books b ON bd.BookID = b.BookID
                    JOIN Users u ON br.UserID = u.UserID
                    WHERE bd.ReturnDate IS NULL";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new ReturnRequest
                        {
                            BorrowID = reader["BorrowID"].ToString(),
                            BookID = reader["BookID"].ToString(),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                            DueDate = Convert.ToDateTime(reader["DueDate"]),
                            UserID = reader["UserID"].ToString(),
                            UserEmail = reader["UserEmail"].ToString(),
                            UserPhone = reader["UserPhone"].ToString()
                        });
                    }
                }
            }

            return View(list);
        }
        public ActionResult ReturnRequests()
        {
            var list = new List<BorrowDetailViewModel>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"
                SELECT bd.BorrowID, bd.BookID, b.Title, bd.BorrowDate, bd.DueDate, bd.IsReturnRequested
                FROM BorrowDetails bd
                JOIN Books b ON bd.BookID = b.BookID
                WHERE bd.IsReturnRequested = 1 AND bd.ReturnDate IS NULL";

                SqlCommand cmd = new SqlCommand(query, con);

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    list.Add(new BorrowDetailViewModel
                    {
                        BorrowID = rdr["BorrowID"].ToString(),
                        BookID = rdr["BookID"].ToString(),
                        Title = rdr["Title"].ToString(),
                        BorrowDate = Convert.ToDateTime(rdr["BorrowDate"]),
                        DueDate = Convert.ToDateTime(rdr["DueDate"]),
                        IsReturnRequested = Convert.ToBoolean(rdr["IsReturnRequested"])
                    });
                }
            }

            return View(list);
        }

        [HttpPost]
        public ActionResult ConfirmReturn(string borrowId, string bookId)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"UPDATE BorrowDetails 
                                 SET ReturnDate = GETDATE(), IsReturnRequested = 0
                                 WHERE BorrowID = @BorrowID AND BookID = @BookID AND ReturnDate IS NULL";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@BorrowID", borrowId);
                cmd.Parameters.AddWithValue("@BookID", bookId);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            return RedirectToAction("ReturnRequests");
        }

        public ActionResult CategoryList()
        {
            List<Categories> categories = new List<Categories>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "SELECT category_id, category_name FROM Categories";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Categories
                        {
                            category_id = reader["category_id"].ToString(),
                            category_name = reader["category_name"].ToString()
                        });
                    }
                }
            }

            return View(categories);
        }

        public ActionResult AddCategory()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddCategory(Categories category)
        {
            if (!ModelState.IsValid)
                return View(category);

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "INSERT INTO Categories (category_id, category_name) VALUES (@id, @name)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", category.category_id);
                cmd.Parameters.AddWithValue("@name", category.category_name);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            TempData["SuccessMessage"] = "✅ Category added successfully!";
            return RedirectToAction("AddCategory");
        }
            

    }
}