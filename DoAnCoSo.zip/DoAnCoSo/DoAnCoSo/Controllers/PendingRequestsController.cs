﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class PendingRequestsController : Controller
    {
        private readonly string conStr = @"Server=THANHNHAN\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        // GET: PendingRequests
        public new ActionResult Request()
        {
            var pending = new List<Borrowing>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"SELECT b.BorrowID, b.UserID, u.UserRole, b.IsApproved, b.ApprovedBy, b.ApprovedDate
               FROM Borrowing b
               JOIN Users u ON b.UserID = u.UserID
               WHERE b.IsApproved = 0";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        pending.Add(new Borrowing
                        {
                            BorrowID = reader["BorrowID"].ToString(),
                            UserID = reader["UserID"].ToString(),
                            UserRole = reader["UserRole"].ToString(),
                            IsApproved = Convert.ToBoolean(reader["IsApproved"]),
                            ApprovedBy = reader["ApprovedBy"] == DBNull.Value ? null : reader["ApprovedBy"].ToString(),
                            ApprovedDate = reader["ApprovedDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["ApprovedDate"])
                        });
                    }
                }
            }
            return View(pending);
        }

        public ActionResult SubmitBorrowRequest(string userId, List<string> bookIds)
        {
            string borrowId = "BR" + Guid.NewGuid().ToString("N").Substring(0, 6); // Tạo mã mượn mới

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // 1. Tạo bản ghi trong bảng Borrowing
                    string insertBorrowingQuery = @"
                INSERT INTO Borrowing (BorrowID, UserID, IsApproved)
                VALUES (@BorrowID, @UserID, 0)";
                    using (SqlCommand cmd = new SqlCommand(insertBorrowingQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@BorrowID", borrowId);
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.ExecuteNonQuery();
                    }

                    // 2. Tạo bản ghi trong bảng BorrowRequests
                    foreach (var bookId in bookIds)
                    {
                        string insertRequestQuery = @"
                    INSERT INTO BorrowRequests (BorrowID, UserID, BookID)
                    VALUES (@BorrowID, @UserID, @BookID)";
                        using (SqlCommand cmd = new SqlCommand(insertRequestQuery, conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@BorrowID", borrowId);
                            cmd.Parameters.AddWithValue("@UserID", userId);
                            cmd.Parameters.AddWithValue("@BookID", bookId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                    TempData["Success"] = "Request submitted successfully.";
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    TempData["Error"] = "Failed to submit request: " + ex.Message;
                }
            }

            return RedirectToAction("ApprovedUsers"); // hoặc trang khác tùy bạn
        }

        public ActionResult ApprovedUsers()
        {
            List<ApprovedBorrowingViewModel> approvedList = new List<ApprovedBorrowingViewModel>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"
            SELECT br.BorrowID, br.UserID, br.ApprovedBy, br.ApprovedDate,
                   bd.BookID, b.Title, bd.BorrowDate, bd.DueDate, bd.Status
            FROM Borrowing br
            LEFT JOIN BorrowDetails bd ON br.BorrowID = bd.BorrowID
            LEFT JOIN Books b ON bd.BookID = b.BookID
            WHERE br.IsApproved = 1
            ORDER BY br.BorrowID, bd.BookID";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    Dictionary<string, ApprovedBorrowingViewModel> borrowMap = new Dictionary<string, ApprovedBorrowingViewModel>();

                    while (reader.Read())
                    {
                        string borrowId = reader["BorrowID"].ToString();

                        if (!borrowMap.ContainsKey(borrowId))
                        {
                            borrowMap[borrowId] = new ApprovedBorrowingViewModel
                            {
                                BorrowID = borrowId,
                                UserID = reader["UserID"].ToString(),
                                ApprovedBy = reader["ApprovedBy"]?.ToString(),
                                ApprovedDate = reader["ApprovedDate"] as DateTime?,
                                BorrowedBooks = new List<BorrowedBookInfo>()
                            };
                        }

                        // Nếu có dữ liệu sách
                        if (reader["BookID"] != DBNull.Value)
                        {
                            borrowMap[borrowId].BorrowedBooks.Add(new BorrowedBookInfo
                            {
                                BookID = reader["BookID"].ToString(),
                                Title = reader["Title"].ToString(),
                                BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                                DueDate = Convert.ToDateTime(reader["DueDate"]),
                                Status = reader["Status"].ToString()
                            });
                        }
                    }

                    reader.Close();

                    approvedList = borrowMap.Values.ToList();
                }
            }

            return View(approvedList);
        }


        // Hàm kiểm tra người dùng có sách quá hạn hay không
        private bool HasOverdueBooks(string userId)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string sql = @"SELECT COUNT(*) FROM BorrowDetails d
                             INNER JOIN Borrowing b ON d.BorrowID = b.BorrowID
                             WHERE b.UserID = @UserID AND b.IsApproved = 1
                             AND d.DueDate < GETDATE() AND d.ReturnDate IS NULL";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        [HttpPost]
        public ActionResult Approve(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                TempData["Error"] = "Invalid borrow ID.";
                return RedirectToAction("Request");
            }

            string librarianId = Session["LibrarianID"]?.ToString() ?? "Lib01";

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlTransaction transaction = con.BeginTransaction();

                try
                {
                    // 1. Cập nhật trạng thái đã duyệt
                    string updateSql = @"
                UPDATE Borrowing
                SET IsApproved = 1,
                    ApprovedBy = @ApprovedBy,
                    ApprovedDate = GETDATE()
                WHERE BorrowID = @BorrowID";

                    using (SqlCommand cmd = new SqlCommand(updateSql, con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@ApprovedBy", librarianId);
                        cmd.Parameters.AddWithValue("@BorrowID", id);
                        cmd.ExecuteNonQuery();
                    }

                    // 2. Lấy danh sách BookID từ BorrowRequests
                    List<string> bookIds = new List<string>();
                    string getBooksSql = "SELECT BookID FROM BorrowRequests WHERE BorrowID = @BorrowID";

                    using (SqlCommand cmd = new SqlCommand(getBooksSql, con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@BorrowID", id);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookIds.Add(reader["BookID"].ToString());
                            }
                        }
                    }

                    if (bookIds.Count == 0)
                        throw new Exception("Book not found in the borrow request.");

                    // 3. Thêm bản ghi vào BorrowDetails cho mỗi BookID
                    string insertSql = @"
                INSERT INTO BorrowDetails (BorrowID, BookID, BorrowDate, DueDate, IsReturnRequested)
                VALUES (@BorrowID, @BookID, GETDATE(), DATEADD(DAY, 15, GETDATE()), 0)";

                    foreach (var bookId in bookIds)
                    {
                        using (SqlCommand cmd = new SqlCommand(insertSql, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@BorrowID", id);
                            cmd.Parameters.AddWithValue("@BookID", bookId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                    TempData["Success"] = "✅ Borrow request approved successfully.";
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    TempData["Error"] = "❌ Duyệt thất bại: " + ex.Message;
                }
            }

            return RedirectToAction("Request");
        }




    }
}