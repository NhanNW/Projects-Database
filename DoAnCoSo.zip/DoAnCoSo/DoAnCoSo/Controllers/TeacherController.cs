﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class TeacherController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        // GET: Teacher
        public ActionResult TeacherDashboard()
        {
            var books = new List<Book>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"SELECT BookID, Title, Author, Publisher, BookImage, YearPublished, 
                                      CategoryID, TotalCopies, AvailableCopies, Description, Status 
                               FROM Books";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        books.Add(new Book
                        {
                            BookID = reader["BookID"].ToString(),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            Publisher = reader["Publisher"].ToString(),
                            BookImage = reader["BookImage"] != DBNull.Value ? reader["BookImage"].ToString() : null,
                            YearPublished = reader["YearPublished"] != DBNull.Value ? Convert.ToInt32(reader["YearPublished"]) : 0,
                            CategoryID = reader["CategoryID"].ToString(),
                            TotalCopies = reader["TotalCopies"] != DBNull.Value ? Convert.ToInt32(reader["TotalCopies"]) : 0,
                            AvailableCopies = reader["AvailableCopies"] != DBNull.Value ? Convert.ToInt32(reader["AvailableCopies"]) : 0,
                            Description = reader["Description"] != DBNull.Value ? reader["Description"].ToString() : "",
                            Status = reader["Status"] != DBNull.Value && Convert.ToBoolean(reader["Status"])
                        });
                    }

                }
            }
            if (Session["User"] != null)
            {
                Session.Clear(); // Đăng xuất
            }
            return View(books);
        }

        public ActionResult Catalog(string searchTitle = "", string category = "")
        {
            List<Book> books = new List<Book>();
            List<SelectListItem> categories = new List<SelectListItem>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                // Lấy danh sách thể loại cho dropdown
                string catQuery = "SELECT category_id, category_name FROM Categories";
                using (SqlCommand catCmd = new SqlCommand(catQuery, con))
                using (SqlDataReader catReader = catCmd.ExecuteReader())
                {
                    while (catReader.Read())
                    {
                        categories.Add(new SelectListItem
                        {
                            Value = catReader["category_id"].ToString(),
                            Text = catReader["category_name"].ToString()
                        });
                    }
                }

                // Tạo câu truy vấn sách có điều kiện lọc
                string bookQuery = @"SELECT * FROM Books WHERE 1=1";

                if (!string.IsNullOrEmpty(searchTitle))
                {
                    bookQuery += " AND (Title LIKE @Search OR Author LIKE @Search)";
                }
                if (!string.IsNullOrEmpty(category))
                {
                    bookQuery += " AND CategoryID = @Category";
                }

                using (SqlCommand cmd = new SqlCommand(bookQuery, con))
                {
                    if (!string.IsNullOrEmpty(searchTitle))
                        cmd.Parameters.AddWithValue("@Search", "%" + searchTitle + "%");

                    if (!string.IsNullOrEmpty(category))
                        cmd.Parameters.AddWithValue("@Category", category);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            books.Add(new Book
                            {
                                BookID = reader["BookID"].ToString(),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Publisher = reader["Publisher"].ToString(),
                                BookImage = reader["BookImage"].ToString(),
                                YearPublished = reader["YearPublished"] as int?,
                                CategoryID = reader["CategoryID"].ToString(),
                                TotalCopies = reader["TotalCopies"] as int?,
                                AvailableCopies = reader["AvailableCopies"] as int?,
                                Description = reader["Description"].ToString(),
                                Status = Convert.ToBoolean(reader["Status"])
                            });
                        }
                    }
                }
            }

            ViewBag.Categories = categories;
            return View(books);
        }

        public ActionResult Search(string keyword)
        {
            var books = new List<Book>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"
            SELECT BookID, Title, Author, Publisher, BookImage, YearPublished, 
                   CategoryID, TotalCopies, AvailableCopies, Description, Status 
            FROM Books
            WHERE BookID LIKE @kw OR Title LIKE @kw OR CategoryID LIKE @kw";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@kw", "%" + keyword + "%");

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            books.Add(new Book
                            {
                                BookID = reader["BookID"].ToString(),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Publisher = reader["Publisher"].ToString(),
                                BookImage = reader["BookImage"].ToString(),
                                YearPublished = Convert.ToInt32(reader["YearPublished"]),
                                CategoryID = reader["CategoryID"].ToString(),
                                TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                                AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                                Description = reader["Description"].ToString(),
                                Status = Convert.ToBoolean(reader["Status"])
                            });
                        }
                    }
                }
            }

            return View("Index", books);
        }

        public ActionResult List(string sortOrder)
        {
            List<Book> books = new List<Book>();
            string query = "SELECT * FROM Books";

            // Xử lý thứ tự sắp xếp
            switch (sortOrder)
            {
                case "name_asc":
                    query += " ORDER BY Title ASC";
                    break;
                case "name_desc":
                    query += " ORDER BY Title DESC";
                    break;
            }

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Book book = new Book
                    {
                        BookID = reader["BookID"].ToString(),
                        Title = reader["Title"].ToString(),
                        Author = reader["Author"].ToString(),
                        Publisher = reader["Publisher"].ToString(),
                        YearPublished = Convert.ToInt32(reader["YearPublished"]),
                        TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                        AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                        Status = Convert.ToBoolean(reader["Status"]),
                        BookImage = reader["BookImage"].ToString()
                    };
                    books.Add(book);
                }

                conn.Close();
            }

            // Tạo HTML
            if (books.Count == 0)
            {
                return Content("<p>No books available.</p>");
            }

            StringBuilder html = new StringBuilder();
            html.Append("<div class='book-container'>");

            foreach (var book in books)
            {
                html.Append($@"
                    <div class='book-card'>
                        <h4>{book.Title}</h4>
                        <img src='/BookImages/{book.BookImage}' alt='{book.Title}' style='max-width:100%; height:auto; border-radius:8px;' />
                        <p><strong>ID:</strong> {book.BookID}</p>
                        <p><strong>Author:</strong> {book.Author}</p>
                        <p><strong>Publisher:</strong> {book.Publisher}</p>
                        <p><strong>Year:</strong> {book.YearPublished}</p>
                        <p><strong>Total:</strong> {book.TotalCopies}</p>
                        <p><strong>Available:</strong> {book.AvailableCopies}</p>
                        <p><strong>Status:</strong> {(book.Status ? "Available" : "Discontinued")}</p>
                    </div>
                ");
            }

            html.Append("</div>");
            return Content(html.ToString());
        }

        // GET: Borrow Request Form
        public ActionResult BorrowRequest()
        {
            ViewBag.HideSearch = true;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BorrowRequestConfirm()
        {
            ViewBag.HideSearch = true;
            string userID = Session["UserID"] as string;

            if (string.IsNullOrEmpty(userID))
            {
                ViewBag.Message = "You need to log in to send a book borrowing request.";
                return View("BorrowRequest");
            }

            System.Diagnostics.Debug.WriteLine("Current UserID: " + userID);

            string borrowID = GenerateBorrowID();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"INSERT INTO Borrowing (BorrowID, UserID, IsApproved, ApprovedBy, ApprovedDate) 
                       VALUES (@BorrowID, @UserID, @IsApproved, NULL, NULL)";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@BorrowID", borrowID);
                    cmd.Parameters.AddWithValue("@UserID", userID);
                    cmd.Parameters.AddWithValue("@IsApproved", false);

                    cmd.ExecuteNonQuery();
                }
            }
            Session.Remove("Cart");

            var now = DateTime.Now;
            int startHour = 7;
            int endHour = 17;

            if (now.Hour >= startHour && now.Hour < endHour)
            {
                ViewBag.Message = "Your borrowing request has been successfully submitted. Please wait for approval within 2-3 hours.";
            }
            else
            {
                ViewBag.Message = "The borrow request has been submitted successfully. Since it is currently outside of office hours, the request will be processed during the next business hours.";
            }

            return View("BorrowRequest");
        }

        private string GenerateBorrowID()
        {
            int count = 1;

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = "SELECT COUNT(*) FROM Borrowing";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    count = (int)cmd.ExecuteScalar() + 1;
                }
            }

            return "BR" + count.ToString("D4");
        }

        public ActionResult BorrowHistory()
        {
            ViewBag.HideSearch = true;

            string userID = Session["UserID"] as string;

            if (string.IsNullOrEmpty(userID))
            {
                ViewBag.Message = "You must be logged in to view borrow history.";
                return View(new List<BorrowDetails>());
            }

            var borrowHistory = new List<BorrowDetails>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"
                SELECT bd.BorrowID, bd.BookID, bd.Quantity, bd.BorrowDate, bd.DueDate, bd.ReturnDate, bd.Status
                FROM BorrowDetails bd
                JOIN Borrowing b ON bd.BorrowID = b.BorrowID
                WHERE b.UserID = @UserID";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", userID);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            borrowHistory.Add(new BorrowDetails
                            {
                                BorrowID = reader["BorrowID"].ToString(),
                                BookID = reader["BookID"].ToString(),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                BorrowDate = reader["BorrowDate"] as DateTime?,
                                DueDate = Convert.ToDateTime(reader["DueDate"]),
                                ReturnDate = reader["ReturnDate"] as DateTime?,
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }
            }

            return View(borrowHistory);
        }

        public ActionResult MyBorrow()
        {
            var userId = Session["UserID"]?.ToString();
            if (string.IsNullOrEmpty(userId))
                return RedirectToAction("Login", "Account");

            var list = new List<BorrowDetailViewModel>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"
                SELECT bd.BorrowID, bd.BookID, b.Title, bd.BorrowDate, bd.DueDate, bd.IsReturnRequested, bd.Status
                FROM BorrowDetails bd
                JOIN Books b ON bd.BookID = b.BookID
                JOIN Borrowing br ON bd.BorrowID = br.BorrowID
                WHERE br.UserID = @UserID AND bd.ReturnDate IS NULL";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserID", userId);

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    list.Add(new BorrowDetailViewModel
                    {
                        BorrowID = rdr["BorrowID"].ToString(),
                        BookID = rdr["BookID"].ToString(),
                        Title = rdr["Title"].ToString(),
                        BorrowDate = Convert.ToDateTime(rdr["BorrowDate"]),
                        DueDate = Convert.ToDateTime(rdr["DueDate"]),
                        IsReturnRequested = Convert.ToBoolean(rdr["IsReturnRequested"]),
                        Status = rdr["Status"].ToString()
                    });
                }
            }

            return View(list);
        }

        [HttpPost]
        public ActionResult RequestReturn(string borrowId, string bookId)
        {
            if (string.IsNullOrEmpty(borrowId) || string.IsNullOrEmpty(bookId))
                return RedirectToAction("MyBorrow");

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"UPDATE BorrowDetails 
                                 SET IsReturnRequested = 1
                                 WHERE BorrowID = @BorrowID AND BookID = @BookID AND ReturnDate IS NULL";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@BorrowID", borrowId);
                cmd.Parameters.AddWithValue("@BookID", bookId);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            return RedirectToAction("MyBorrow");
        }
    }
}