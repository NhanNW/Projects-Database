﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class ReservationController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        public ActionResult Create(string bookId)
        {
            if (string.IsNullOrEmpty(bookId))
                return HttpNotFound();

            int available = 0;

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT AvailableCopies FROM Books WHERE BookID = @BookID", conn);
                cmd.Parameters.AddWithValue("@BookID", bookId);
                var result = cmd.ExecuteScalar();
                if (result != null)
                    available = Convert.ToInt32(result);
            }

            if (available > 0)
            {
                TempData["Error"] = "This book is available. No need to reserve.";
                return RedirectToAction("Index", "Home");
            }

            ViewBag.BookID = bookId;
            return View();
        }

        // POST: Reservation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(string bookId, int quantity = 1)
        {
            string userId = Session["UserID"]?.ToString();
            if (string.IsNullOrEmpty(userId))
            {
                TempData["Error"] = "You must log in to reserve a book.";
                return RedirectToAction("Login", "Account");
            }

            bool alreadyReserved = false;

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                // Kiểm tra đã đặt chưa
                var checkCmd = new SqlCommand("SELECT COUNT(*) FROM Reservations WHERE BookID = @BookID AND UserID = @UserID AND Status = 'Pending'", conn);
                checkCmd.Parameters.AddWithValue("@BookID", bookId);
                checkCmd.Parameters.AddWithValue("@UserID", userId);
                int count = (int)checkCmd.ExecuteScalar();
                alreadyReserved = count > 0;

                if (!alreadyReserved)
                {
                    string reservationId = Guid.NewGuid().ToString("N").Substring(0, 6).ToUpper();

                    string insert = @"INSERT INTO Reservations 
                    (ReservationID, UserID, BookID, ReservationDate, Quantity, Status) 
                    VALUES (@ReservationID, @UserID, @BookID, @Date, @Quantity, 'Pending')";

                    var insertCmd = new SqlCommand(insert, conn);
                    insertCmd.Parameters.AddWithValue("@ReservationID", reservationId);
                    insertCmd.Parameters.AddWithValue("@UserID", userId);
                    insertCmd.Parameters.AddWithValue("@BookID", bookId);
                    insertCmd.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCmd.Parameters.AddWithValue("@Quantity", quantity);
                    insertCmd.ExecuteNonQuery();
                }
            }

            TempData[alreadyReserved ? "Error" : "Success"] = alreadyReserved
                ? "You have already reserved this book."
                : "Book reserved successfully.";

            return RedirectToAction("MyReservations");
        }

        // GET: Reservation/MyReservations
        public ActionResult MyReservations()
        {
            string userId = Session["UserID"]?.ToString();

            if (string.IsNullOrEmpty(userId))
            {
                TempData["Error"] = "You must be logged in to view your reservations.";
                return RedirectToAction("Login", "Account");
            }

            var reservations = new List<Reservation>();

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = @"
        SELECT r.ReservationID, r.ReservationDate, r.Quantity, r.Status,
               b.Title
        FROM Reservations r
        JOIN Books b ON r.BookID = b.BookID
        WHERE r.UserID = @UserID";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserID", userId);
                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    reservations.Add(new Reservation
                    {
                        ReservationID = reader["ReservationID"].ToString(),
                        BookTitle = reader["Title"].ToString(),
                        ReservationDate = Convert.ToDateTime(reader["ReservationDate"]),
                        Quantity = Convert.ToInt32(reader["Quantity"]),
                        Status = reader["Status"].ToString()
                    });
                }
            }

            return View(reservations);
        }


        public ActionResult PendingReservations()
        {
            var reservations = new List<Reservation>();
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = @"
            SELECT r.ReservationID, r.ReservationDate, r.Quantity, r.Status,
                   r.UserID, b.Title AS BookTitle
            FROM Reservations r
            JOIN Books b ON r.BookID = b.BookID
            WHERE r.Status = 'Pending'
            ORDER BY r.ReservationDate ASC";

                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    reservations.Add(new Reservation
                    {
                        ReservationID = reader["ReservationID"].ToString(),
                        BookTitle = reader["BookTitle"].ToString(),
                        UserID = reader["UserID"].ToString(),
                        ReservationDate = Convert.ToDateTime(reader["ReservationDate"]),
                        Quantity = Convert.ToInt32(reader["Quantity"]),
                        Status = reader["Status"].ToString()
                    });
                }
            }

            return View(reservations);
        }

        [HttpPost]
        public ActionResult ApproveReservation(string id)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = @"
                UPDATE Reservations 
                SET Status = 'Completed', 
                    ApprovedBy = @ApproverID, 
                    ApprovedDate = GETDATE()
                WHERE ReservationID = @id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@ApproverID", Session["UserID"]); // thủ thư đang đăng nhập
                conn.Open();
                cmd.ExecuteNonQuery();
            }

            return RedirectToAction("PendingReservations");
        }

        [HttpPost]
        public ActionResult RejectReservation(string id)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = "UPDATE Reservations SET Status = 'Cancelled' WHERE ReservationID = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }

            return RedirectToAction("PendingReservations");
        }
    }
}