﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class HomeController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        public ActionResult Index()
        {
            var books = new List<Book>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"SELECT BookID, Title, Author, Publisher, BookImage, YearPublished, 
                                      CategoryID, TotalCopies, AvailableCopies, Description, Status 
                               FROM Books";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        books.Add(new Book
                        {
                            BookID = reader["BookID"].ToString(),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            Publisher = reader["Publisher"].ToString(),
                            BookImage = reader["BookImage"] != DBNull.Value ? reader["BookImage"].ToString() : null,
                            YearPublished = reader["YearPublished"] != DBNull.Value ? Convert.ToInt32(reader["YearPublished"]) : 0,
                            CategoryID = reader["CategoryID"].ToString(),
                            TotalCopies = reader["TotalCopies"] != DBNull.Value ? Convert.ToInt32(reader["TotalCopies"]) : 0,
                            AvailableCopies = reader["AvailableCopies"] != DBNull.Value ? Convert.ToInt32(reader["AvailableCopies"]) : 0,
                            Description = reader["Description"] != DBNull.Value ? reader["Description"].ToString() : "",
                            Status = reader["Status"] != DBNull.Value && Convert.ToBoolean(reader["Status"])
                        });
                    }

                }
            }
            if (Session["User"] != null)
            {
                Session.Clear(); // Đăng xuất
            }
            return View(books);
        }

        public ActionResult Search(string keyword)
        {
            var books = new List<Book>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = @"
            SELECT BookID, Title, Author, Publisher, BookImage, YearPublished, 
                   CategoryID, TotalCopies, AvailableCopies, Description, Status 
            FROM Books
            WHERE BookID LIKE @kw OR Title LIKE @kw OR CategoryID LIKE @kw";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@kw", "%" + keyword + "%");

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            books.Add(new Book
                            {
                                BookID = reader["BookID"].ToString(),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Publisher = reader["Publisher"].ToString(),
                                BookImage = reader["BookImage"].ToString(),
                                YearPublished = Convert.ToInt32(reader["YearPublished"]),
                                CategoryID = reader["CategoryID"].ToString(),
                                TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                                AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                                Description = reader["Description"].ToString(),
                                Status = Convert.ToBoolean(reader["Status"])
                            });
                        }
                    }
                }
            }

            return View("Index", books);
        }

        public ActionResult Catalog(string searchTitle = "", string category = "")
        {
            List<Book> books = new List<Book>();
            List<SelectListItem> categories = new List<SelectListItem>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                // Lấy danh sách thể loại cho dropdown
                string catQuery = "SELECT category_id, category_name FROM Categories";
                using (SqlCommand catCmd = new SqlCommand(catQuery, con))
                using (SqlDataReader catReader = catCmd.ExecuteReader())
                {
                    while (catReader.Read())
                    {
                        categories.Add(new SelectListItem
                        {
                            Value = catReader["category_id"].ToString(),
                            Text = catReader["category_name"].ToString()
                        });
                    }
                }

                // Tạo câu truy vấn sách có điều kiện lọc
                string bookQuery = @"SELECT * FROM Books WHERE 1=1";

                if (!string.IsNullOrEmpty(searchTitle))
                {
                    bookQuery += " AND (Title LIKE @Search OR Author LIKE @Search)";
                }
                if (!string.IsNullOrEmpty(category))
                {
                    bookQuery += " AND CategoryID = @Category";
                }

                using (SqlCommand cmd = new SqlCommand(bookQuery, con))
                {
                    if (!string.IsNullOrEmpty(searchTitle))
                        cmd.Parameters.AddWithValue("@Search", "%" + searchTitle + "%");

                    if (!string.IsNullOrEmpty(category))
                        cmd.Parameters.AddWithValue("@Category", category);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            books.Add(new Book
                            {
                                BookID = reader["BookID"].ToString(),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Publisher = reader["Publisher"].ToString(),
                                BookImage = reader["BookImage"].ToString(),
                                YearPublished = reader["YearPublished"] as int?,
                                CategoryID = reader["CategoryID"].ToString(),
                                TotalCopies = reader["TotalCopies"] as int?,
                                AvailableCopies = reader["AvailableCopies"] as int?,
                                Description = reader["Description"].ToString(),
                                Status = Convert.ToBoolean(reader["Status"])
                            });
                        }
                    }
                }
            }

            ViewBag.Categories = categories;
            return View(books);
        }

        public ActionResult List(string sortOrder)
        {
            List<Book> books = new List<Book>();
            string query = "SELECT * FROM Books";

            // Xử lý thứ tự sắp xếp
            switch (sortOrder)
            {
                case "name_asc":
                    query += " ORDER BY Title ASC";
                    break;
                case "name_desc":
                    query += " ORDER BY Title DESC";
                    break;
            }

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Book book = new Book
                    {
                        BookID = reader["BookID"]?.ToString(),
                        Title = reader["Title"]?.ToString(),
                        Author = reader["Author"]?.ToString(),
                        Publisher = reader["Publisher"]?.ToString(),
                        YearPublished = reader["YearPublished"] == DBNull.Value ? 0 : Convert.ToInt32(reader["YearPublished"]),
                        TotalCopies = reader["TotalCopies"] == DBNull.Value ? 0 : Convert.ToInt32(reader["TotalCopies"]),
                        AvailableCopies = reader["AvailableCopies"] == DBNull.Value ? 0 : Convert.ToInt32(reader["AvailableCopies"]),
                        Status = reader["Status"] == DBNull.Value ? false : Convert.ToBoolean(reader["Status"]),
                        BookImage = reader["BookImage"]?.ToString()
                    };
                    books.Add(book);
                }

                conn.Close();
            }

            // Tạo HTML
            if (books.Count == 0)
            {
                return Content("<p>No books available.</p>");
            }

            StringBuilder html = new StringBuilder();
            html.Append("<div class='book-container'>");

            foreach (var book in books)
            {
                html.Append($@"
                    <div class='book-card'>
                        <h4>{book.Title}</h4>
                        <img src='/BookImages/{book.BookImage}' alt='{book.Title}' style='max-width:100%; height:auto; border-radius:8px;' />
                        <p><strong>ID:</strong> {book.BookID}</p>
                        <p><strong>Author:</strong> {book.Author}</p>
                        <p><strong>Publisher:</strong> {book.Publisher}</p>
                        <p><strong>Year:</strong> {book.YearPublished}</p>
                        <p><strong>Total:</strong> {book.TotalCopies}</p>
                        <p><strong>Available:</strong> {book.AvailableCopies}</p>
                        <p><strong>Status:</strong> {(book.Status ? "Available" : "Discontinued")}</p>
                    </div>
                ");
            }
            html.Append("</div>");
            return Content(html.ToString());
        }
    }


}
