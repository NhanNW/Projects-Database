﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class LibraryStatsController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        // GET: LibraryStats
        public ActionResult LibrarianStatistics()
        {
            var stats = new LibrarianStatsViewModel();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                // Tổng số sách
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM Books", con))
                    stats.TotalBooks = (int)cmd.ExecuteScalar();

                // Tổng số người dùng
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM Users", con))
                    stats.TotalUsers = (int)cmd.ExecuteScalar();

                // Sách đang mượn
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM BorrowDetails WHERE Status = 'Borrowed'", con))
                    stats.CurrentlyBorrowed = (int)cmd.ExecuteScalar();

                // Sách quá hạn
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM BorrowDetails WHERE ReturnDate IS NULL AND DueDate < GETDATE()", con))
                    stats.OverdueBooks = (int)cmd.ExecuteScalar();

                // Đã duyệt
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM Borrowing WHERE IsApproved = 1", con))
                    stats.ApprovedBorrowings = (int)cmd.ExecuteScalar();

                // Sách không còn lưu hành
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM Books WHERE Status = 0", con))
                    stats.DiscontinuedBooks = (int)cmd.ExecuteScalar();
            }

            return View(stats);
        }

        public ActionResult MonthlyBooks()
        {
            var monthlyStats = new List<MonthlyBorrowStat>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string sql = @"
            SELECT MONTH(CreatedDate) AS Month, COUNT(*) AS Total
            FROM Books
            WHERE YEAR(CreatedDate) = YEAR(GETDATE())
            GROUP BY MONTH(CreatedDate)
            ORDER BY Month";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        monthlyStats.Add(new MonthlyBorrowStat
                        {
                            Month = Convert.ToInt32(rdr["Month"]),
                            Total = Convert.ToInt32(rdr["Total"])
                        });
                    }
                }
            }
            ViewBag.ChartTitle = "Monthly Added Books";
            ViewBag.ChartLabel = "New Books";
            return View("MonthlyChart", monthlyStats);
        }

        public ActionResult MonthlyUsers()
        {
            var monthlyStats = new List<MonthlyBorrowStat>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string sql = @"
            SELECT MONTH(UserCreateDate) AS Month, COUNT(*) AS Total
            FROM Users
            WHERE YEAR(UserCreateDate) = YEAR(GETDATE())
            GROUP BY MONTH(UserCreateDate)
            ORDER BY Month";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        monthlyStats.Add(new MonthlyBorrowStat
                        {
                            Month = Convert.ToInt32(rdr["Month"]),
                            Total = Convert.ToInt32(rdr["Total"])
                        });
                    }
                }
            }
            ViewBag.ChartTitle = "Monthly Registered Users";
            ViewBag.ChartLabel = "Users";
            return View("MonthlyChart", monthlyStats);
        }

        public ActionResult MonthlyBorrowed()
        {
            var monthlyStats = new List<MonthlyBorrowStat>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string sql = @"
            SELECT 
                MONTH(BorrowDate) AS BorrowMonth, 
                COUNT(*) AS TotalBorrows
            FROM BorrowDetails
            WHERE YEAR(BorrowDate) = YEAR(GETDATE())
            GROUP BY MONTH(BorrowDate)
            ORDER BY BorrowMonth";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        monthlyStats.Add(new MonthlyBorrowStat
                        {
                            Month = Convert.ToInt32(rdr["BorrowMonth"]),
                            Total = Convert.ToInt32(rdr["TotalBorrows"])
                        });
                    }
                }
            }
            ViewBag.ChartTitle = "Monthly Book Borrowings";
            ViewBag.ChartLabel = "Borrowings";
            return View("MonthlyChart", monthlyStats);
        }

        public ActionResult MonthlyOverdue()
        {
            var monthlyStats = new List<MonthlyBorrowStat>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string sql = @"
            SELECT MONTH(DueDate) AS Month, COUNT(*) AS Total
            FROM BorrowDetails
            WHERE ReturnDate IS NULL AND DueDate < GETDATE() AND YEAR(DueDate) = YEAR(GETDATE())
            GROUP BY MONTH(DueDate)
            ORDER BY Month";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        monthlyStats.Add(new MonthlyBorrowStat
                        {
                            Month = Convert.ToInt32(rdr["Month"]),
                            Total = Convert.ToInt32(rdr["Total"])
                        });
                    }
                }
            }
            ViewBag.ChartTitle = "Monthly Overdue Books";
            ViewBag.ChartLabel = "Overdue Books";

            return View("MonthlyChart", monthlyStats);
        }

        public ActionResult MonthlyApproved()
        {
            var monthlyStats = new List<MonthlyBorrowStat>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string sql = @"
            SELECT MONTH(ApprovedDate) AS Month, COUNT(*) AS Total
            FROM Borrowing
            WHERE IsApproved = 1 AND YEAR(ApprovedDate) = YEAR(GETDATE())
            GROUP BY MONTH(ApprovedDate)
            ORDER BY Month";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        monthlyStats.Add(new MonthlyBorrowStat
                        {
                            Month = Convert.ToInt32(rdr["Month"]),
                            Total = Convert.ToInt32(rdr["Total"])
                        });
                    }
                }
            }
            ViewBag.ChartTitle = "Monthly Approved Borrowings";
            ViewBag.ChartLabel = "Approvals";
            return View("MonthlyChart", monthlyStats);
        }

        public ActionResult MonthlyDiscontinued()
        {
            var monthlyStats = new List<MonthlyBorrowStat>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string sql = @"
            SELECT MONTH(UpdatedDate) AS Month, COUNT(*) AS Total
            FROM Books
            WHERE Status = 0 AND YEAR(UpdatedDate) = YEAR(GETDATE())
            GROUP BY MONTH(UpdatedDate)
            ORDER BY Month";

                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        monthlyStats.Add(new MonthlyBorrowStat
                        {
                            Month = Convert.ToInt32(rdr["Month"]),
                            Total = Convert.ToInt32(rdr["Total"])
                        });
                    }
                }
            }
            ViewBag.ChartTitle = "Monthly Discontinued Books";
            ViewBag.ChartLabel = "Discontinued Books";
            return View("MonthlyChart", monthlyStats);
        }
    }
}