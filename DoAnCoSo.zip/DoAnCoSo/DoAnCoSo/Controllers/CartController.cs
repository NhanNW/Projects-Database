﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class CartController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";
        
        [AllowAnonymous]
        public ActionResult Index()
        {
            var books = Session["Cart"] as List<Book> ?? new List<Book>();
            return View(books);
        }

        public ActionResult AddToCartBook(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return RedirectToAction("Index");
            }

            id = id.Trim();
            var cart = Session["Cart"] as List<Book> ?? new List<Book>();
            int maxBooksAllowed = 5;
            if (cart.Count > maxBooksAllowed)
            {
                TempData["CartMessage"] = "❌ You have reached the maximum number of books allowed.";
                return RedirectToAction("Index");
            }
            Book book = null;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "SELECT * FROM Books WHERE BookID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        book = new Book
                        {
                            BookID = reader["BookID"].ToString(),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            Publisher = reader["Publisher"].ToString(),
                            YearPublished = Convert.ToInt32(reader["YearPublished"]),
                            TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                            AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                            Status = Convert.ToBoolean(reader["Status"]),
                            BookImage = reader["BookImage"].ToString()
                        };
                    }
                }
            }

            if (book != null)
            {
                if (book.AvailableCopies > 0)
                {
                    cart.Add(book);
                    Session["Cart"] = cart;
                }
                else
                {
                    Session["CartMessage"] = "This book is currently unavailable.";
                    return RedirectToAction("StudentDashboard", "Student");
                }
            }

            Session["Cart"] = cart;
            return RedirectToAction("Index");
        }

        public ActionResult RemoveFromCartBook(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return RedirectToAction("Index");
            }

            // Loại bỏ khoảng trắng ở đầu và cuối id
            id = id.Trim();

            var cart = Session["Cart"] as List<Book> ?? new List<Book>();

            // Kiểm tra giá trị id và các đối tượng trong giỏ hàng
            var book = cart.OfType<Book>().FirstOrDefault(b => b.BookID.Trim() == id);  
            if (book != null)
            {
                cart.Remove(book);
            }
            else
            {
                // Debugging để kiểm tra trường hợp không tìm thấy
                Console.WriteLine($"Không tìm thấy sách với ID: {id}");
            }

            Session["Cart"] = cart;
            return RedirectToAction("Index");
        }
    }
}