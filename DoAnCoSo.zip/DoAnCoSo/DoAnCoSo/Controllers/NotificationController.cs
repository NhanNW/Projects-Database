﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DoAnCoSo.Models;

namespace DoAnCoSo.Controllers
{
    public class NotificationController : Controller
    {
        private readonly string conStr = @"Server=THANHNHAN\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        // GET: Notification
        public ActionResult Index()
        {
            string userId = Session["UserID"]?.ToString();
            if (string.IsNullOrEmpty(userId))
                return RedirectToAction("Login", "Account");

            var notifications = new List<Notification>();

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                string query = @"SELECT NotificationID, Title, Message, CreatedDate, IsRead
                                 FROM Notifications
                                 WHERE UserID = @UserID
                                 ORDER BY CreatedDate DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserID", userId);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    notifications.Add(new Notification
                    {
                        NotificationID = reader["NotificationID"].ToString(),
                        Title = reader["Title"].ToString(),
                        Message = reader["Message"].ToString(),
                        CreatedDate = Convert.ToDateTime(reader["CreatedDate"]),
                        IsRead = Convert.ToBoolean(reader["IsRead"])
                    });
                }
            }

            Session["NotificationCount"] = notifications.FindAll(n => !n.IsRead).Count;

            return View(notifications);
        }

        // GET: Notification/MarkAsRead/{id}
        public ActionResult MarkAsRead(string id)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();
                string query = "UPDATE Notifications SET IsRead = 1 WHERE NotificationID = @ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.ExecuteNonQuery();
            }

            // Cập nhật lại số thông báo chưa đọc
            string userId = Session["UserID"]?.ToString();
            if (!string.IsNullOrEmpty(userId))
            {
                Session["NotificationCount"] = GetUnreadNotificationCount(userId);
            }

            return RedirectToAction("Index");
        }

        private int GetUnreadNotificationCount(string userId)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Notifications WHERE UserID = @UserID AND IsRead = 0";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserID", userId);

                return (int)cmd.ExecuteScalar();
            }
        }


        // Hàm kiểm tra và gửi thông báo đến sinh viên
        public void CheckDueDates()
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                string query = @"
            SELECT bd.BorrowID, br.UserID, bd.DueDate, bd.ReturnDate, bd.Status, b.Title
            FROM BorrowDetails bd
            JOIN Borrowing br ON bd.BorrowID = br.BorrowID
            JOIN Books b ON bd.BookID = b.BookID
            WHERE br.IsApproved = 1 AND bd.ReturnDate IS NULL
        ";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string userId = reader["UserID"].ToString();
                    DateTime dueDate = Convert.ToDateTime(reader["DueDate"]);
                    string title = reader["Title"].ToString();
                    DateTime today = DateTime.Now;

                    int daysLeft = (dueDate - today).Days;
                    int daysOverdue = (today - dueDate).Days;

                    string message = null;
                    string titleMsg = null;

                    if (daysLeft <= 3 && daysLeft >= 0)
                    {
                        titleMsg = "Sắp đến hạn trả sách";
                        message = $"Nhắc nhở: Sách '{title}' sẽ hết hạn sau {daysLeft} ngày.";
                    }
                    else if (daysOverdue > 0 && daysOverdue <= 15)
                    {
                        titleMsg = "Quá hạn trả sách";
                        message = $"Sách '{title}' đã quá hạn {daysOverdue} ngày. Phạt: 30.000 VNĐ.";
                    }
                    else if (daysOverdue > 15)
                    {
                        titleMsg = "Quá hạn nghiêm trọng";
                        message = $"Sách '{title}' đã quá hạn {daysOverdue} ngày. Phạt: 50.000 VNĐ.";
                    }

                    if (message != null)
                    {
                        InsertNotification(userId, titleMsg, message);
                    }
                }
            }
        }


        // Gửi thông báo vào DB nếu chưa tồn tại
        private void InsertNotification(string userId, string title, string message)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                string insert = @"
            IF NOT EXISTS (
                SELECT 1 FROM Notifications 
                WHERE UserID = @UserID 
                  AND Title = @Title 
                  AND Message = @Message 
                  AND CreatedDate >= DATEADD(HOUR, -12, GETDATE()) -- Không tạo lại trong 12h
            )
            BEGIN
                INSERT INTO Notifications (NotificationID, UserID, Title, Message, CreatedBy)
                VALUES (@NotificationID, @UserID, @Title, @Message, @CreatedBy)
            END";

                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.AddWithValue("@NotificationID", GenerateNotificationID(conn));
                cmd.Parameters.AddWithValue("@UserID", userId);
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@Message", message);
                cmd.Parameters.AddWithValue("@CreatedBy", "Lib01"); // hoặc lấy từ Session["UserID"]

                cmd.ExecuteNonQuery();
            }
        }


        private string GenerateNotificationID(SqlConnection conn)
        {
            string prefix = "NT";
            string query = "SELECT TOP 1 NotificationID FROM Notifications ORDER BY NotificationID DESC";
            SqlCommand cmd = new SqlCommand(query, conn);
            var result = cmd.ExecuteScalar();
            int nextId = 1;

            if (result != null)
            {
                string lastId = result.ToString().Substring(2); // remove "NT"
                nextId = int.Parse(lastId) + 1;
            }

            return prefix + nextId.ToString("D4"); // NT0001, NT0002, ...
        }

        public void LoadNotificationCount(string userId)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Notifications WHERE UserID = @UserID AND IsRead = 0";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserID", userId);

                int count = (int)cmd.ExecuteScalar();

                // ✅ Gán session đúng cách
                System.Web.HttpContext context = System.Web.HttpContext.Current;
                if (context != null && context.Session != null)
                {
                    context.Session["NotificationCount"] = count;
                }
            }
        }
    }
}