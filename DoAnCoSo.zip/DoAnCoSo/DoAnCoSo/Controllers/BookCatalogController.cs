﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCoSo.Controllers
{
    public class BookCatalogController : Controller
    {
        private readonly string conStr = @"Server=THANHNHAN\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        // GET: BookCatalog
        public ActionResult Catalog(string searchTitle = "", string category = "")
        {
            List<Book> books = new List<Book>();
            List<SelectListItem> categories = new List<SelectListItem>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                // Lấy danh sách thể loại cho dropdown
                string catQuery = "SELECT category_id, category_name FROM Categories";
                using (SqlCommand catCmd = new SqlCommand(catQuery, con))
                using (SqlDataReader catReader = catCmd.ExecuteReader())
                {
                    while (catReader.Read())
                    {
                        categories.Add(new SelectListItem
                        {
                            Value = catReader["category_id"].ToString(),
                            Text = catReader["category_name"].ToString()
                        });
                    }
                }

                // Tạo câu truy vấn sách có điều kiện lọc
                string bookQuery = @"SELECT * FROM Books WHERE 1=1";

                if (!string.IsNullOrEmpty(searchTitle))
                {
                    bookQuery += " AND (Title LIKE @Search OR Author LIKE @Search)";
                }
                if (!string.IsNullOrEmpty(category))
                {
                    bookQuery += " AND CategoryID = @Category";
                }

                using (SqlCommand cmd = new SqlCommand(bookQuery, con))
                {
                    if (!string.IsNullOrEmpty(searchTitle))
                        cmd.Parameters.AddWithValue("@Search", "%" + searchTitle + "%");

                    if (!string.IsNullOrEmpty(category))
                        cmd.Parameters.AddWithValue("@Category", category);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            books.Add(new Book
                            {
                                BookID = reader["BookID"].ToString(),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Publisher = reader["Publisher"].ToString(),
                                BookImage = reader["BookImage"].ToString(),
                                YearPublished = reader["YearPublished"] as int?,
                                CategoryID = reader["CategoryID"].ToString(),
                                TotalCopies = reader["TotalCopies"] as int?,
                                AvailableCopies = reader["AvailableCopies"] as int?,
                                Description = reader["Description"].ToString(),
                                Status = Convert.ToBoolean(reader["Status"])
                            });
                        }
                    }
                }
            }

            ViewBag.Categories = categories;
            return View(books);
        }
    }
}