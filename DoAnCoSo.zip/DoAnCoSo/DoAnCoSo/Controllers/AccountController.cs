﻿using DoAnCoSo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DoAnCoSo.Controllers
{
    public class AccountController : Controller
    {
        private readonly string conStr = "Server=THANHNHAN\\SQLEXPRESS;Database=LibrarySystem;Integrated Security=True;";

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Login(User model, bool? RememberMe, string selectedRole)
        {
            bool isRemembered = RememberMe ?? false;

            if (!string.IsNullOrEmpty(selectedRole))
            {
                string actualRole = Session["Role"]?.ToString();

                if (selectedRole == actualRole)
                {
                    switch (selectedRole)
                    {
                        case "Student":
                            return RedirectToAction("StudentDashboard", "Student");
                        case "Teacher":
                            return RedirectToAction("TeacherDashboard", "Teacher");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "Incorrect role selected. Please choose your assigned role.";
                    ViewBag.ShowRoleSelection = true;
                    return View();
                }
            }

            if (string.IsNullOrEmpty(model.UserID) || string.IsNullOrEmpty(model.Password))
            {
                ViewBag.ErrorMessage = "Please enter both UserID and Password.";
                return View();
            }

            if (model.UserID == "Lib01" && model.Password == "librarian123")
            {
                Session["UserID"] = "Lib01";
                Session["Role"] = "Librarian";
                FormsAuthentication.SetAuthCookie("Lib01", isRemembered);

                if (isRemembered)
                {
                    HttpCookie cookie = new HttpCookie("UserLogin", "admin");
                    cookie.Expires = DateTime.Now.AddDays(7);
                    Response.Cookies.Add(cookie);
                }

                return RedirectToAction("LibrarianDashboard", "Librarian");
            }

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string sql = "SELECT UserID, UserRole FROM Users WHERE UserID = @UserID AND UserPassword = @UserPassword AND UserStatus = 1";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", model.UserID);
                    cmd.Parameters.AddWithValue("@UserPassword", model.Password);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string role = reader["UserRole"].ToString();

                            Session["UserID"] = model.UserID;
                            Session["Role"] = role;
                            FormsAuthentication.SetAuthCookie(model.UserID, isRemembered);

                            if (isRemembered)
                            {
                                HttpCookie cookie = new HttpCookie("UserLogin", model.UserID);
                                cookie.Expires = DateTime.Now.AddDays(7);
                                Response.Cookies.Add(cookie);
                            }

                            ViewBag.ShowRoleSelection = true;
                            return View();
                        }
                    }
                }
            }

            // If credentials are invalid and user not found in DB
            ViewBag.ErrorMessage = "Invalid login credentials.";
            return View();
        }


        public ActionResult Logout()
        {
            Session.Clear(); // hoặc Session["User"] = null;
            return RedirectToAction("Index", "Home");
        }


        //[HttpGet]
        //public ActionResult ChangePassword()
        //{
        //    ViewBag.HideSearch = true;

        //    return View();
        //}

        //// POST: Account/ChangePassword
        //[HttpPost]
        //public ActionResult ChangePassword(string userId, string oldPassword, string newPassword)
        //{
        //    ViewBag.HideSearch = true;

        //    if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword))
        //    {
        //        ViewBag.Message = "Please fill in all information.";
        //        return View();
        //    }
        //    using (SqlConnection con = new SqlConnection(conStr))
        //    {
        //        con.Open();

        //        // Kiểm tra UserID và mật khẩu cũ
        //        string checkSql = "SELECT COUNT(*) FROM Users WHERE UserID = @UserID AND UserPassword = @OldPassword";
        //        using (SqlCommand checkCmd = new SqlCommand(checkSql, con))
        //        {
        //            checkCmd.Parameters.AddWithValue("@UserID", userId);
        //            checkCmd.Parameters.AddWithValue("@OldPassword", oldPassword);

        //            int count = (int)checkCmd.ExecuteScalar();
        //            if (count == 0)
        //            {
        //                ViewBag.Message = "Wrong UserID or old password!";
        //                return View();
        //            }
        //        }

        //        // Cập nhật mật khẩu mới
        //        string updateSql = "UPDATE Users SET UserPassword = @NewPassword WHERE UserID = @UserID";
        //        using (SqlCommand updateCmd = new SqlCommand(updateSql, con))
        //        {
        //            updateCmd.Parameters.AddWithValue("@NewPassword", newPassword);
        //            updateCmd.Parameters.AddWithValue("@UserID", userId);

        //            updateCmd.ExecuteNonQuery();
        //        }
        //    }

        //    ViewBag.Message = "Password changed successfully!";
        //    return View();
        //}


        [HttpGet]
        public ActionResult SendEmail()
        {
            ViewBag.HideSearch = true;

            return View();
        }
        [HttpPost]
        public ActionResult SendEmail(string email)
        {
            ViewBag.HideSearch = true;

            if (string.IsNullOrEmpty(email))
            {
                ViewBag.Error = "Please enter your email address.";
                return View();
            }
            // Tạo mã xác thực ngẫu nhiên 4 chữ số
            Random rnd = new Random();
            int code = rnd.Next(1000, 9999);
            TempData["VerifyCode"] = code; // Lưu để xác minh sau (tuỳ bạn xử lý tiếp)
            try
            {
                string fromMail = "luubao952004@gmail.com";
                string fromPassword = "igloafebbanhznpa";

                MailMessage message = new MailMessage();
                message.From = new MailAddress(fromMail);
                message.Subject = "Password Reset Verification Code";
                message.To.Add(new MailAddress(email));
                message.Body = $"<html><body><h2>Your verification code is: <strong>{code}</strong></h2></body></html>";
                message.IsBodyHtml = true;

                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587)
                {
                    Credentials = new System.Net.NetworkCredential(fromMail, fromPassword),
                    EnableSsl = true
                };

                smtpClient.Send(message);
                ViewBag.Success = "✅ A verification code has been sent to your email.";

                return RedirectToAction("ForgotPassword");
            }

            catch (Exception ex)
            {
                ViewBag.Error = "❌ Unable to send email. Please try again later.";
            }

            return View();
        }

        // Hiển thị form nhập mã và đổi mật khẩu
        [HttpGet]
        public ActionResult ForgotPassword()
        {
            ViewBag.HideSearch = true;

            // Lấy dữ liệu cần thiết từ TempData nếu có
            ViewBag.Email = TempData["Email"];
            ViewBag.UserID = TempData["UserID"];
            ViewBag.Success = TempData["Success"];

            // Giữ lại TempData để dùng cho post
            TempData.Keep("VerifyCode");
            TempData.Keep("Email");
            TempData.Keep("UserID");

            return View();
        }

        [HttpPost]
        public ActionResult ForgotPasswordConfirm(string email, string userId, string code1, string code2, string code3, string code4,
                                      string newPassword, string confirmPassword)
        {
            ViewBag.HideSearch = true;

            string enteredCode = $"{code1}{code2}{code3}{code4}";
            string expectedCode = TempData["VerifyCode"]?.ToString();

            ViewBag.Email = email;
            ViewBag.UserID = userId;

            TempData.Keep("VerifyCode");

            if (string.IsNullOrEmpty(expectedCode) || enteredCode != expectedCode)
            {
                ViewBag.Error = "❌ The verification code is incorrect or has expired.";
                return View("ForgotPassword");
            }

            if (string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                ViewBag.Error = "❌ Please enter both new password and confirmation.";
                return View("ForgotPassword");
            }

            if (newPassword != confirmPassword)
            {
                ViewBag.Error = "❌ Password confirmation does not match.";
                return View("ForgotPassword");
            }

            using (SqlConnection conn = new SqlConnection(conStr))
            {
                conn.Open();

                // Kiểm tra UserID và Email trong database
                string checkUserSql = "SELECT COUNT(*) FROM Users WHERE UserID = @UserID";
                SqlCommand checkCmd = new SqlCommand(checkUserSql, conn);
                checkCmd.Parameters.AddWithValue("@UserID", userId);

                int userCount = (int)checkCmd.ExecuteScalar();
                if (userCount == 0)
                {
                    ViewBag.Error = "❌ This UserID was not found in the system.";
                    return View("ForgotPassword");
                }


                // Cập nhật mật khẩu (nên hash trước khi lưu)
                string updateSql = "UPDATE Users SET UserPassword = @UserPassword WHERE UserID = @UserID";
                SqlCommand updateCmd = new SqlCommand(updateSql, conn);
                updateCmd.Parameters.AddWithValue("@UserPassword", newPassword); // Nên hash mật khẩu trước khi lưu
                updateCmd.Parameters.AddWithValue("@UserID", userId);

                int rowsAffected = updateCmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    TempData.Clear();
                    TempData["Success"] = "✅ Your password has been successfully reset! Please log in.";
                    return RedirectToAction("Login");
                }
                else
                {
                    ViewBag.Error = "❌ An error occurred while updating the password.";
                    return View("ForgotPassword");
                }
            }
        }
    }
}